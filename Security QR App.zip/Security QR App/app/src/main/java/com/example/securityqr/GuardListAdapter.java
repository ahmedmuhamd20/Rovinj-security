package com.example.securityqr;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class GuardListAdapter extends ArrayAdapter<Guard_Model> {

    private final Activity context;
    ArrayList<Guard_Model> data = new ArrayList<>();
    private DatabaseReference db;

    public GuardListAdapter(Activity context, ArrayList<Guard_Model> data) {
        super(context, R.layout.guard_view, data);
        // TODO Auto-generated constructor stub
        Log.d("view2", String.valueOf(data.size()) );
        this.context=context;
        this.data=data;
    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.guard_view, null,true);
        db = FirebaseDatabase.getInstance().getReference();

        Log.d("view", String.valueOf(this.data.size()));
        TextView Name_field = (TextView) rowView.findViewById(R.id.qr_name);

        Name_field.setText(data.get(position).Name);


        return rowView;

    };
}