package com.example.securityqr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import android.util.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class View_Report extends AppCompatActivity {

    private DatabaseReference mDatabase;
    ArrayList<Report_Model> report = new ArrayList<>();
    ListView list;
    static Button Download;
    ProgressBar Progress_Spin;
    DownloadManager downloadManager ;
    StorageReference storageReference = FirebaseStorage.getInstance().getReference();
    ArrayList<Image_Model> imageNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_view_report);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        Download = findViewById(R.id.download);
        list = findViewById(R.id.list);
        Progress_Spin = findViewById(R.id.download_spin);

        StorageReference storageRef = storageReference.child("report_images");

        storageRef.listAll()
                .addOnSuccessListener(listResult -> {

                    for (StorageReference item : listResult.getItems()) {
                        StorageReference img_data = storageReference.child("report_images").child(item.getName());
                        img_data.getBytes(Long.MAX_VALUE).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                byte[] imageBytes = task.getResult();
                                imageNames.add(new Image_Model(item.getName(), imageBytes));
//                                Log.d("Image_Names", convertBytesToBase64(imageBytes));
                                Log.d("Image_Namex", item.getName());
                                if(listResult.getItems().size()==imageNames.size())
                                {
                                    Download.setVisibility(View.VISIBLE);
                                }
                                Log.d("image_size", String.valueOf(listResult.getItems().size())+" : "+imageNames.size());

                            } else {
                                Exception exception = task.getException();
                                Log.d("Image_Error", exception.toString());
                            }
                        });
                    }

                })
                .addOnFailureListener(e -> {
                    // Handle any errors that occur during the retrieval
                    Log.d("Image_Error", e.toString());
                    Log.e("Firebase Storage", "Error getting image names", e);
                });

        Download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ArrayList<Map<String, Object>> Data_Array = new ArrayList<>();

                for(int i=0;i<report.size();i++)
                {
                    Map<String, Object> temp = new HashMap<>();
                    String img = "null";
                    Log.d("Image_size", String.valueOf(imageNames.size()));
                    for(int j=0;j<imageNames.size();j++)
                    {
                        String Image_details[] = imageNames.get(j).name.split(";");
                        String Date[] = Image_details[3].split("_");
                        String Dates = Date[0]+"-"+Date[1]+"-"+Date[2];
                        Log.d("Image_Details",Image_details[0]+"..."+report.get(i).ID);
                        Log.d("Image_Details",Image_details[2]+"..."+report.get(i).Time);
                        Log.d("Image_Details",Dates+"..."+report.get(i).Date.replace("/","-"));
                        if(Image_details[0].equals(report.get(i).ID) && Image_details[2].equals( report.get(i).Time) && Dates.equals(report.get(i).Date.replace("/","-")))
                        {
                            Log.d("Image_Details_",Image_details[0]+"..."+report.get(i).ID);
                            Log.d("Image_Details_",Image_details[2]+"..."+report.get(i).Time);
                            Log.d("Image_Details_",Dates+"..."+report.get(i).Date.replace("/","-"));

                            img=convertBytesToBase64(imageNames.get(j).imageBytes);

                        }
                    }
                    if (!img.equals("null"))
                    {
                        Log.d("Image_Details_",img);
                        temp.put("image", img);
                    }
                    else
                    {
                        temp.put("image", "null");
                    }


                    temp.put("ID", report.get(i).ID);
                    temp.put("Name", report.get(i).Name);
                    String Date[] = report.get(i).Date.split("/");
                    temp.put("Date", Date[0]+"-"+Date[1]+"-"+"20"+Date[2]);
                    temp.put("Time", report.get(i).Time);
                    temp.put("Report", report.get(i).Report);
                    temp.put("Oštećenja", report.get(i).First);
                    temp.put("Nepoštivanje_unutarnjeg_reda", report.get(i).Second);
                    temp.put("Ciljani_pregled_(KONTROLA)", report.get(i).Third);



                    Data_Array.add(temp);
                }

                Gson gson = new Gson();
                String json = gson.toJson(Data_Array);

                Log.d("Map_Data", json);
                downloadpdf(json);

//                for(int i=0;i<Data_Array.size();i++)
//                {
//                    for(String data : Data_Array.get(i).keySet())
//                    {
//                        Log.d("Map_Data", data+" : "+Data_Array.get(i).get(data));
//                    }
//                }

            }
        });

        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                report.clear();
                // Get Post object and use the values to update the UI

                try {
                    Map<String, Object> data = (Map<String,Object>) dataSnapshot.child("Reports").getValue();
                    for(String x : data.keySet())
                    {
                        String[] splitted_data = x.split(";");
                        Map<String, Object> data1 = (Map<String,Object>) data.get(x);

//                    Log.d("Details_", splitted_data[1]+" "+splitted_data[3]+" "+data1.get("details"));
                        report.add(new Report_Model(splitted_data[0],splitted_data[1].replace("_"," "),splitted_data[3].replace("_","/"),splitted_data[2],data1.get("details").toString(),data1.get("Krađe_oštećenja_provale").toString(),data1.get("Nepoštivanje_unutarnjeg_reda").toString(),data1.get("Ciljani_pregled_(KONTROLA)").toString()));
//                    Log.d("firebase_attendance", x.toString()+" "+data.get(x).toString());
                    }

                    for(int i=0;i<report.size();i++)
                    {
                        Log.d("firebase_report", report.get(i).Name+" : "+report.get(i).Report);
                    }

                    sort();
                }
                catch (Exception e)
                {
                    Toast.makeText(View_Report.this, "Nema izvještaja za prikaz", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(View_Report.this, "No reports to show", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.d("firebase_report", databaseError.toException().toString());
            }
        };
        mDatabase.addValueEventListener(postListener);
    }

    void adapter_report(ArrayList<Report_Model> report_list)
    {
        for(int i=0;i<report_list.size();i++)
        {
            ReportListAdapter adapter=new ReportListAdapter(View_Report.this,report_list);

            list.setAdapter(adapter);
            adapter.notifyDataSetChanged();


            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    // TODO Auto-generated method stub

//                    Selected_Guard = Guard.get(position).ID;
//                    Intent intent = new Intent(getApplicationContext(), Guard_Details.class);
//                    startActivity(intent);

                }
            });
        }

    }

    public void getrequest(String filename)
    {
        downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        String token="";
        String url = "https://rovajsecurity.b1-media.hr/downloader.php?filename="+filename;
        Log.d("parsed_log", url);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI |
                DownloadManager.Request.NETWORK_MOBILE);

        request.setTitle("Izvještaji.pdf");
        request.setDescription("Izvještaji.");

        request.allowScanningByMediaScanner();
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"Izvještaji.pdf");
        request.setMimeType("*/*");

        Toast.makeText(getApplicationContext(), "Izvještaji.pdf Downloaded", Toast.LENGTH_SHORT).show();
        downloadManager.enqueue(request);
    }

    public void downloadpdf(String json)
    {
        Activity get = this;
        Download.setVisibility(View.GONE);
        Progress_Spin.setVisibility(View.VISIBLE);
        StringRequest myReq = new StringRequest(Request.Method.POST,
                "https://rovajsecurity.b1-media.hr/index.php",
                new Response.Listener<String>(){ @Override
                public void onResponse(String response) {
                    boolean flag = false;
                    Log.d("Map_data_res",response.toString());

                    String filename;
                    try {
                        JSONObject json = new JSONObject(response);
                        filename = json.get("filename").toString();
                        getrequest(filename);
                        Download.setVisibility(View.VISIBLE);
                        Progress_Spin.setVisibility(View.GONE);
//                        System.out.println(json.toString());
                    } catch (JSONException e) {
                        Download.setVisibility(View.VISIBLE);
                        Progress_Spin.setVisibility(View.GONE);
                        Toast.makeText(View_Report.this, "Pokušajte ponovno", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }

                }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Download.setVisibility(View.VISIBLE);
                        Progress_Spin.setVisibility(View.GONE);
                        Toast.makeText(View_Report.this, "Pokušajte ponovno", Toast.LENGTH_SHORT).show();
//                        Log.d("res", error.getMessage());
                    }
                }){
            protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                try {
                    params.put("report", json);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(myReq);
    }

    void sort()
    {
        Comparator<Report_Model> customComparator = new Comparator<Report_Model>() {
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

            DateFormat dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

            @Override
            public int compare(Report_Model obj1, Report_Model obj2) {
                try {
                    Date dateTime1 = dateTimeFormat.parse(obj1.getDate() + " " + obj1.getTime());
                    Date dateTime2 = dateTimeFormat.parse(obj2.getDate() + " " + obj2.getTime());
                    return dateTime2.compareTo(dateTime1); // Compare in reverse order (newest to oldest)
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                return 0;
            }
        };

        // Sort the report list using the custom comparator
        Collections.sort(report, customComparator);
        adapter_report(report);
    }

    public static String convertBytesToBase64(byte[] imageBytes) {
        String base64String = Base64.encodeToString(imageBytes, 0);
        return base64String;
    }

}