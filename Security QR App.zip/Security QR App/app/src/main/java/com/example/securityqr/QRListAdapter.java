package com.example.securityqr;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class QRListAdapter extends ArrayAdapter<String> {

    private final Activity context;
    ArrayList<String> data = new ArrayList<>();
    private DatabaseReference db;

    public QRListAdapter(Activity context, ArrayList<String> data) {
        super(context, R.layout.qr_view, data);
        // TODO Auto-generated constructor stub
        Log.d("view2", String.valueOf(data.size()) );
        this.context=context;
        this.data=data;
    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.qr_view, null,true);
        db = FirebaseDatabase.getInstance().getReference();

        Log.d("view", String.valueOf(this.data.size()));
        TextView Name_field = (TextView) rowView.findViewById(R.id.qr_name);
        LinearLayout Delete_field = (LinearLayout) rowView.findViewById(R.id.delete);

        Name_field.setText(data.get(position));

        Delete_field.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                db.child("QR").child(data.get(position).replace(" ","_").replace(".","_").replace("$","_").replace("#","_").replace("[","_").replace("]","_").replace("/","_").replace(",","_")).removeValue();
                Toast.makeText(getContext(), "QR kod obrisan, Molimo osvježite stranicu", Toast.LENGTH_SHORT).show();
//                Toast.makeText(getContext(), "QR Deleted, Please reload page", Toast.LENGTH_SHORT).show();
            }
        });



        return rowView;

    };
}