package com.example.securityqr;

public class Guard_Model {

    String Name;
    String ID;
    String Password;
    String Contact;

    public Guard_Model(String name, String ID, String password, String contact) {
        Name = name;
        this.ID = ID;
        Password = password;
        Contact = contact;
    }
}
