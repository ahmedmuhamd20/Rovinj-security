package com.example.securityqr;

public class Report_Model {

    String ID;
    String Name;
    String Date;
    String Time;
    String Report;
    String First;
    String Second;
    String Third;

    public Report_Model(String ID, String name, String date, String time, String report, String first, String second, String third) {
        this.ID = ID;
        Name = name;
        Date = date;
        Time = time;
        Report = report;
        Second = second;
        First = first;
        Third = third;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getReport() {
        return Report;
    }

    public void setReport(String report) {
        Report = report;
    }

    public String getFirst() {
        return First;
    }

    public void setFirst(String first) {
        First = first;
    }

    public String getSecond() {
        return Second;
    }

    public void setSecond(String second) {
        Second = second;
    }

    public String getThird() {
        return Third;
    }

    public void setThird(String third) {
        Third = third;
    }
}
