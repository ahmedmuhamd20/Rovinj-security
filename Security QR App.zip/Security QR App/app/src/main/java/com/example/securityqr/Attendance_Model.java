package com.example.securityqr;

public class Attendance_Model {

    String ID;
    String Name;
    String Date;
    String Time;
    String Location;

    public Attendance_Model(String ID, String name, String date, String time, String location) {
        this.ID = ID;
        Name = name;
        Date = date;
        Time = time;
        Location = location;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }
}
