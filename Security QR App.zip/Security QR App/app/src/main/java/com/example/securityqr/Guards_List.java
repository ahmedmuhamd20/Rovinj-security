package com.example.securityqr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Map;

public class Guards_List extends AppCompatActivity {

    static ArrayList<Guard_Model> Guard = new ArrayList<>();
    static ArrayList<String> Guard_ID = new ArrayList<>();

    DatabaseReference mDatabase;
    ListView list;
    ImageView reload;
    static String Selected_Guard;
    Button add_guard;

    @Override
    protected void onRestart() {
        super.onRestart();
        adaptercall();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_guards_list);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        list = findViewById(R.id.qr);
        reload = findViewById(R.id.reload);
        add_guard = findViewById(R.id.add_guard);

        adaptercall();

        add_guard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Add_Guard.class);
                startActivity(intent);

            }
        });

        reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adaptercall();
            }
        });
    }

    void adaptercall()
    {
        mDatabase.child("Users").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
//                                    Snackbar.make(findViewById(android.R.id.content), "Invalid Credentials", Snackbar.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(), "Neispravni podatci", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase2",String.valueOf(task.getResult().getChildrenCount()));

                    if(task.getResult().getChildrenCount()!=0)
                    {
                        Map<String, Object> data = (Map<String,Object>) task.getResult().getValue();
                        Guard_ID.clear();

                        for(String x : data.keySet())
                        {
                            Guard_ID.add(x);
                            Log.d("firebase", String.valueOf(x));
                        }

                        adapter_guards();
                    }
                    else
                    {
                        Toast.makeText(Guards_List.this, "Još nisu dodani čuvari", Toast.LENGTH_SHORT).show();
//                        Toast.makeText(Guards_List.this, "No Guards Added Yet", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
    }


    void adapter_guards()
    {
        Guard.clear();
        for(int i=0;i<Guard_ID.size();i++)
        {
            String ID = Guard_ID.get(i);
            mDatabase.child("Users").child(ID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (!task.isSuccessful()) {
//                                    Snackbar.make(findViewById(android.R.id.content), "Invalid Credentials", Snackbar.LENGTH_SHORT).show();
                        Toast.makeText(getApplicationContext(), "Neispravni podatci", Toast.LENGTH_SHORT).show();
//                        Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                        Log.e("firebase", "Error getting data", task.getException());
                    }
                    else {
                        Map<String, Object> data = (Map<String,Object>) task.getResult().getValue();


                        Log.d("firebase2", String.valueOf(data.get("name")));
                        Guard.add(new Guard_Model(String.valueOf(data.get("name")).replace("_"," "), ID, String.valueOf(data.get("password")), String.valueOf(data.get("contact"))));

                        GuardListAdapter adapter=new GuardListAdapter(Guards_List.this,Guard);

                        list.setAdapter(adapter);
                        adapter.notifyDataSetChanged();


                        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                            @Override
                            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                                // TODO Auto-generated method stub

                                Selected_Guard = Guard.get(position).ID;
                                Intent intent = new Intent(getApplicationContext(), Guard_Details.class);
                                startActivity(intent);

                            }
                        });

                    }
                }
            });
        }

    }


}