package com.example.securityqr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Attendance extends AppCompatActivity {

    private DatabaseReference mDatabase;
    ArrayList<Attendance_Model> attendance = new ArrayList<>();
    ListView list;
    Button Download;
    DownloadManager downloadManager ;
    TextView Username;
    static Attendance_Model Selected_Guard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        setContentView(R.layout.activity_attenance);

        list = findViewById(R.id.attendance);
        Download = findViewById(R.id.download);
        Username = findViewById(R.id.username);
        mDatabase = FirebaseDatabase.getInstance().getReference();


        Username.setText("Welcome, "+MainActivity.emr_string);

        Download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ArrayList<Map<String, Object>> Data_Array = new ArrayList<>();

                for(int i=0;i<attendance.size();i++)
                {
                    Map<String, Object> temp = new HashMap<>();
                    temp.put("ID", attendance.get(i).ID);
                    temp.put("Name", attendance.get(i).Name);
                    temp.put("Date", attendance.get(i).Date);
                    temp.put("Time", attendance.get(i).Time);
                    temp.put("Location", attendance.get(i).Location);
                    Data_Array.add(temp);
                }

                Gson gson = new Gson();
                String json = gson.toJson(Data_Array);

                downloadpdf(json);

                Log.d("Map_Data", json);



//                for(int i=0;i<Data_Array.size();i++)
//                {
//                    for(String data : Data_Array.get(i).keySet())
//                    {
//                        Log.d("Map_Data", data+" : "+Data_Array.get(i).get(data));
//                    }
//                }

            }
        });

        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                attendance.clear();
                // Get Post object and use the values to update the UI
                try {
                    Map<String, Object> data = (Map<String,Object>) dataSnapshot.child("Attendance").getValue();

                    if( data.size()>0)
                    {
                        for(String x : data.keySet())
                        {
                            String[] splitted_data = x.split(";");
                            attendance.add(new Attendance_Model(splitted_data[0],splitted_data[1].replace("_"," "),splitted_data[3].replace("_","/"),splitted_data[2],data.get(x).toString()));
//                    Log.d("firebase_attendance", x.toString()+" "+data.get(x).toString());
                        }

                        for(int i=0;i<attendance.size();i++)
                        {
                            Log.d("firebase_attendance", attendance.get(i).Name+" : "+attendance.get(i).Location);
                        }
                        sort();

                    }
                }
                catch (Exception e)
                {
                    Toast.makeText(Attendance.this, "Nema otkucanih QR kodova", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(Attendance.this, "No Attendance Marked Yet", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.d("firebase_attendance", databaseError.toException().toString());
            }
        };
        mDatabase.addValueEventListener(postListener);

    }

    void adapter_attendance(ArrayList<Attendance_Model> attendance_list)
    {

        AttendanceListAdapter adapter=new AttendanceListAdapter(Attendance.this,attendance_list);

        list.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        if(attendance_list.size()>0)
            Download.setVisibility(View.VISIBLE);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub

                    Selected_Guard = attendance_list.get(position);
                    Intent intent = new Intent(getApplicationContext(), Attendance_Details.class);
                    startActivity(intent);
                    Log.d("Attendance_details", Selected_Guard.Name);
            }
        });

    }

    public void getrequest(String filename)
    {
        downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        String token="";
        String url = "https://rovajsecurity.b1-media.hr/downloader.php?filename="+filename;
        Log.d("parsed_log", url);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI |
                DownloadManager.Request.NETWORK_MOBILE);

        request.setTitle("Report.pdf");
        request.setDescription("DR LAB.");

        request.allowScanningByMediaScanner();
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);


        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"Report.pdf");
        request.setMimeType("*/*");

        Toast.makeText(getApplicationContext(), "Report.pdf Downloaded", Toast.LENGTH_SHORT).show();
        downloadManager.enqueue(request);
    }


    public void downloadpdf(String json)
    {
        Activity get = this;
        StringRequest myReq = new StringRequest(Request.Method.POST,
                "https://rovajsecurity.b1-media.hr/index.php",
                new Response.Listener<String>(){ @Override
                public void onResponse(String response) {
                    boolean flag = false;

                    Log.d("Map_data_res",response.toString());
                    String filename;
                    try {
                        JSONObject json = new JSONObject(response);
                        filename = json.get("filename").toString();
                        getrequest(filename);
                        Log.d("download_attendance", "ok");
//                        System.out.println(json.toString());
                    } catch (JSONException e) {
                        Log.d("download_attendance", e.toString());
                        e.printStackTrace();
                    }


                }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
//                        Log.d("res", error.getMessage());
                    }
                }){
            protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                try {
                    params.put("attendance", json);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(myReq);
    }

    void sort()
    {
        Comparator<Attendance_Model> customComparator = new Comparator<Attendance_Model>() {
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

            DateFormat dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

            @Override
            public int compare(Attendance_Model obj1, Attendance_Model obj2) {
                try {
                    Date dateTime1 = dateTimeFormat.parse(obj1.getDate() + " " + obj1.getTime());
                    Date dateTime2 = dateTimeFormat.parse(obj2.getDate() + " " + obj2.getTime());
                    return dateTime2.compareTo(dateTime1); // Compare in reverse order (newest to oldest)
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                return 0;
            }
        };


        // Sort the attendance list using the custom comparator
        Collections.sort(attendance, customComparator);
        adapter_attendance(attendance);

    }
}