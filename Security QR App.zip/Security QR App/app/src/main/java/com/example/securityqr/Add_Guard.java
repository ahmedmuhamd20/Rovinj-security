package com.example.securityqr;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Add_Guard extends AppCompatActivity {

    EditText ID, Name, Contact, Password;
    Button Add;
    DatabaseReference mDatabase;
    TextView Username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        setContentView(R.layout.activity_add_guard);

        ID = findViewById(R.id.ID);
        Name = findViewById(R.id.name);
        Contact = findViewById(R.id.contact);
        Password = findViewById(R.id.password);
        Add = findViewById(R.id.add);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        Username = findViewById(R.id.username);

        Username.setText("Dobrodošli, "+MainActivity.emr_string);
//        Username.setText("Welcome, "+MainActivity.emr_string);

        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = Name.getText().toString();
                String contact = Contact.getText().toString();
                String password = Password.getText().toString();
                String id = ID.getText().toString();

                if(validate_data(name) && validate_data(contact) && validate_data(password) && validate_id(id))
                {
                    mDatabase.child("Users").child(id).child("name").setValue(name);
                    mDatabase.child("Users").child(id).child("password").setValue(password);
                    mDatabase.child("Users").child(id).child("contact").setValue(contact);
                    Toast.makeText(Add_Guard.this, "Korisnik dodan", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });




    }

    boolean validate_data(String data)
    {
        if(data.length()>0)
        {
            if(!data.contains(".") && !data.contains("$") && !data.contains("[") && !data.contains("]") && !data.contains("#") && !data.contains("/"))
            {
                return true;
            }
            else
            {
                Toast.makeText(this, "Izbjegavajte korištenje specijalnih znakova .$%#/", Toast.LENGTH_SHORT).show();
//                Toast.makeText(this, "Avoid Using Special Characters .$[]#/", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        else
        {
            Toast.makeText(this, "Molimo ispunite sva tražena polja", Toast.LENGTH_SHORT).show();
//            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return false;
        }
    }


    boolean validate_id(String data)
    {
        if(data.length()>0)
        {
            if(!data.contains(".") && !data.contains("$") && !data.contains("[") && !data.contains("]") && !data.contains("#") && !data.contains("/") && !data.contains(" ") && !data.contains("_"))
            {
                boolean flag = true;
                for(int i=0;i<Guards_List.Guard_ID.size();i++)
                {
                    if(Guards_List.Guard_ID.get(i).equals(data))
                    {
                        flag = false;
                    }
                }
                if(flag)
                {
                    return true;
                }
                else
                {
                    Toast.makeText(this, "ID je već zauzet, pokušajte drugi ID", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(this, "ID should be unique, try another ID", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
            else
            {
                Toast.makeText(this, "Izbjegavajte korištenje specijalnih znakova .$%#/", Toast.LENGTH_SHORT).show();
//                Toast.makeText(this, "Avoid Using Special Characters .$[]#/ (Space)", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        else
        {
            Toast.makeText(this, "Molimo ispunite sva tražena polja", Toast.LENGTH_SHORT).show();
//            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}