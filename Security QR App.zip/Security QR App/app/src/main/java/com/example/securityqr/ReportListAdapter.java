package com.example.securityqr;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ReportListAdapter extends ArrayAdapter<Report_Model> {

    private final Activity context;
    ArrayList<Report_Model> data = new ArrayList<>();
    private DatabaseReference db;
    DownloadManager downloadManager ;
    StorageReference storageReference = FirebaseStorage.getInstance().getReference();
    ArrayList<Image_Model> imageNames = new ArrayList<>();

    public ReportListAdapter(Activity context, ArrayList<Report_Model> data) {
        super(context, R.layout.report_view, data);
        // TODO Auto-generated constructor stub
        Log.d("view2", String.valueOf(data.size()) );
        this.context=context;
        this.data=data;
    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.report_view, null,true);
        db = FirebaseDatabase.getInstance().getReference();

        Log.d("view", String.valueOf(this.data.size()));
        TextView Name_field = (TextView) rowView.findViewById(R.id.name);
        TextView ID = (TextView) rowView.findViewById(R.id.ID);
        TextView Date = (TextView) rowView.findViewById(R.id.date);
        TextView Time = (TextView) rowView.findViewById(R.id.time);
        TextView Report = (TextView) rowView.findViewById(R.id.report);
        Button Download = (Button) rowView.findViewById(R.id.download);
        ProgressBar Download_Spin = (ProgressBar) rowView.findViewById(R.id.download_spin);

        LinearLayout First = rowView.findViewById(R.id.first);
        LinearLayout Second = rowView.findViewById(R.id.second);
        LinearLayout Third = rowView.findViewById(R.id.third);

        TextView f1 = rowView.findViewById(R.id.f1);
        TextView f2 = rowView.findViewById(R.id.f2);
        TextView f3 = rowView.findViewById(R.id.f3);
        TextView f4 = rowView.findViewById(R.id.f4);

        TextView s1 = rowView.findViewById(R.id.s1);
        TextView s2 = rowView.findViewById(R.id.s2);
        TextView s3 = rowView.findViewById(R.id.s3);
        TextView s4 = rowView.findViewById(R.id.s4);
        TextView s5 = rowView.findViewById(R.id.s5);
        TextView s6 = rowView.findViewById(R.id.s6);

        TextView t1 = rowView.findViewById(R.id.t1);
        TextView t2 = rowView.findViewById(R.id.t2);
        TextView t3 = rowView.findViewById(R.id.t3);
        TextView t4 = rowView.findViewById(R.id.t4);

        Download.setBackgroundResource(R.drawable.img_1);

        if(!data.get(position).First.toString().equals("null"))
        {
            First.setVisibility(View.VISIBLE);
            TextView tv[] = {f1,f2,f3,f4};
            String val[] = data.get(position).First.toString().split(";");

            for(int i=0;i<val.length;i++)
            {
                tv[i].setText(val[i]);
                tv[i].setVisibility(View.VISIBLE);
            }

        }
        if(!data.get(position).Second.toString().equals("null"))
        {
            Second.setVisibility(View.VISIBLE);
            TextView tv[] = {s1,s2,s3,s4,s5,s6};
            String val[] = data.get(position).Second.toString().split(";");

            for(int i=0;i<val.length;i++)
            {
                tv[i].setText(val[i]);
                tv[i].setVisibility(View.VISIBLE);
            }
        }
        if(!data.get(position).Third.toString().equals("null"))
        {
            Third.setVisibility(View.VISIBLE);
            TextView tv[] = {t1,t2,t3,t4};
            String val[] = data.get(position).Third.toString().split(";");

            for(int i=0;i<val.length;i++)
            {
                tv[i].setText(val[i]);
                tv[i].setVisibility(View.VISIBLE);
            }
        }

        Name_field.setText("Ime : "+data.get(position).Name);
        ID.setText("ID : "+data.get(position).ID);
        Date.setText("Datum : "+data.get(position).Date);
        Time.setText("Vrijeme : "+data.get(position).Time);
        Report.setText(data.get(position).Report);

        StorageReference storageRef = storageReference.child("report_images");

        storageRef.listAll()
                .addOnSuccessListener(listResult -> {

                    for (StorageReference item : listResult.getItems()) {
                        StorageReference img_data = storageReference.child("report_images").child(item.getName());
                        img_data.getBytes(Long.MAX_VALUE).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                byte[] imageBytes = task.getResult();
                                imageNames.add(new Image_Model(item.getName(), imageBytes));
//                                Log.d("Image_Names", convertBytesToBase64(imageBytes));
                                Log.d("Image_Namex", item.getName());

                                Log.d("image_size", String.valueOf(listResult.getItems().size())+" : "+position+"::"+imageNames.size());

                            } else {
                                Exception exception = task.getException();
                                Log.d("Image_Error", exception.toString());
                            }
                        });

                    }

                })
                .addOnFailureListener(e -> {
                    // Handle any errors that occur during the retrieval
                    Log.d("Image_Error", e.toString());
                    Log.e("Firebase Storage", "Error getting image names", e);
                });


        Download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (View_Report.Download.getVisibility() != View.VISIBLE)
                {
                    Toast.makeText(getContext(), "Pričekajte nekoliko sekundi i pokušajte ponovo, učitavanje slike...", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    ArrayList<Map<String, Object>> Data_Array = new ArrayList<>();

                    for(int i=0;i<1;i++)
                    {
                        Map<String, Object> temp = new HashMap<>();
                        String img = "null";
                        Log.d("Image_size", String.valueOf(imageNames.size()));
                        for(int j=0;j<imageNames.size();j++)
                        {
                            String Image_details[] = imageNames.get(j).name.split(";");
                            String Date[] = Image_details[3].split("_");
                            String Dates = Date[0]+"-"+Date[1]+"-"+Date[2];
                            Log.d("Image_Details",Image_details[0]+"..."+data.get(position).ID);
                            Log.d("Image_Details",Image_details[2]+"..."+data.get(position).Time);
                            Log.d("Image_Details",Dates+"..."+data.get(i).Date.replace("/","-"));
                            if(Image_details[0].equals(data.get(position).ID) && Image_details[2].equals( data.get(position).Time) && Dates.equals(data.get(position).Date.replace("/","-")))
                            {
                                Log.d("Image_Details_",Image_details[0]+"..."+data.get(position).ID);
                                Log.d("Image_Details_",Image_details[2]+"..."+data.get(position).Time);
                                Log.d("Image_Details_",Dates+"..."+data.get(i).Date.replace("/","-"));

                                img=convertBytesToBase64(imageNames.get(j).imageBytes);

                            }
                        }
                        if (!img.equals("null"))
                        {
                            Log.d("Image_Details_",img);
                            temp.put("image", img);
                        }
                        else
                        {
                            temp.put("image", "null");
                        }
                        temp.put("ID", data.get(position).ID);
                        temp.put("Name", data.get(position).Name);
                        String Date[] = data.get(i).Date.split("/");
                        temp.put("Date", Date[0]+"-"+Date[1]+"-"+"20"+Date[2]);
                        temp.put("Time", data.get(position).Time);
                        temp.put("Report", data.get(position).Report);
                        temp.put("Oštećenja", data.get(position).First);
                        temp.put("Nepoštivanje_unutarnjeg_reda", data.get(position).Second);
                        temp.put("Ciljani_pregled_(KONTROLA)", data.get(position).Third);
                        Data_Array.add(temp);

                    }

                    Gson gson = new Gson();
                    String json = gson.toJson(Data_Array);
                    downloadpdf(json, data.get(position).Name, data.get(position).Date.replace("/","-"), Download, Download_Spin);
                }

            }
        });

        return rowView;

    };

    public void downloadpdf(String json, String name, String date, Button Download, ProgressBar Download_Spin)
    {
        Context get = getContext();
        Download.setVisibility(View.GONE);
        Download_Spin.setVisibility(View.VISIBLE);
        StringRequest myReq = new StringRequest(Request.Method.POST,
                "https://rovajsecurity.b1-media.hr/index.php",
                new Response.Listener<String>(){ @Override
                public void onResponse(String response) {
                    boolean flag = false;
                    Log.d("Map_data_res",response.toString());
                    String filename;
                    try {
                        JSONObject json = new JSONObject(response);
                        filename = json.get("filename").toString();
                        getrequest(filename, name, date);
                        Log.d("download_attendance", "ok");
                        Download.setVisibility(View.VISIBLE);
                        Download_Spin.setVisibility(View.GONE);
//                        System.out.println(json.toString());
                    } catch (JSONException e) {
                        Log.d("download_attendance", e.toString());
                        Download.setVisibility(View.VISIBLE);
                        Download_Spin.setVisibility(View.GONE);
                        Toast.makeText(get, "Pokušajte ponovno", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }

                }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Download.setVisibility(View.VISIBLE);
                        Download_Spin.setVisibility(View.GONE);
                        Toast.makeText(get, "Pokušajte ponovno", Toast.LENGTH_SHORT).show();
//                        Log.d("res", error.getMessage());
                    }
                }){
            protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                try {
                    params.put("report", json);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(get);
        requestQueue.add(myReq);
    }

    public void getrequest(String filename, String name, String date)
    {
        Context get = getContext();
        downloadManager = (DownloadManager) get.getSystemService(Context.DOWNLOAD_SERVICE);
        String token="";
        String url = "https://rovajsecurity.b1-media.hr/downloader.php?filename="+filename;
        Log.d("parsed_log", url);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI |
                DownloadManager.Request.NETWORK_MOBILE);

        request.setTitle("Izvještaj "+name+" "+date+".pdf");
        request.setDescription("DR LAB.");

        request.allowScanningByMediaScanner();
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);


        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"Izvještaj "+name+" "+date+".pdf");
        request.setMimeType("*/*");

        Toast.makeText(get, "Izvještaj "+name+" "+date+".pdf"+" Downloaded", Toast.LENGTH_SHORT).show();
        downloadManager.enqueue(request);
    }

    public static String convertBytesToBase64(byte[] imageBytes) {
        String base64String = Base64.encodeToString(imageBytes, 0);
        return base64String;
    }

}