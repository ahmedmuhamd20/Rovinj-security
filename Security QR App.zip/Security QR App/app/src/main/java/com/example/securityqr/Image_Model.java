package com.example.securityqr;

public class Image_Model {

    String name;
    byte[] imageBytes;

    public Image_Model(String name, byte[] imageBytes) {
        this.name = name;
        this.imageBytes = imageBytes;
    }
}
