package com.example.securityqr;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class GalleryListAdapter extends ArrayAdapter<String> {

    private final Activity context;
    ArrayList<String> data = new ArrayList<>();
    private DatabaseReference db;
    StorageReference storageReference = FirebaseStorage.getInstance().getReference();

    public GalleryListAdapter(Activity context, ArrayList<String> data) {
        super(context, R.layout.gallery_view, data);
        // TODO Auto-generated constructor stub
        Log.d("view2", String.valueOf(data.size()) );
        this.context=context;
        this.data=data;
    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.gallery_view, null,true);
        db = FirebaseDatabase.getInstance().getReference();

        String details[] = data.get(position).split(";");

        Log.d("view", String.valueOf(this.data.size()));
        TextView Name_field = (TextView) rowView.findViewById(R.id.name);
        TextView Time = (TextView) rowView.findViewById(R.id.time);
        TextView Date = (TextView) rowView.findViewById(R.id.date);
        ImageView Image = (ImageView) rowView.findViewById(R.id.image);
        ImageView Delete = (ImageView) rowView.findViewById(R.id.delete);
        ImageView Download = (ImageView) rowView.findViewById(R.id.download);

//        Log.d("Image", data.toString());

        storageReference.child("report").child(data.get(position).toString()).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(Image);
                Download.setVisibility(View.VISIBLE);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // Handle any errors
                Log.d("Image_Error", e.toString());
                Toast.makeText(context.getApplicationContext(), "Pogreška prilikom očitavanja, molimo provjerite Vašu internet konekciju", Toast.LENGTH_SHORT).show();
//                Toast.makeText(context.getApplicationContext(), "Error while loading image, Please check your network", Toast.LENGTH_SHORT).show();
            }
        });

        Name_field.setText(details[1]);
        Time.setText(details[2]);
        Date.setText(details[3].replace("_","/").split("\\.")[0]);

        Download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Drawable drawable = Image.getDrawable();
                Bitmap bitmap = null;
                bitmap = ((BitmapDrawable) drawable).getBitmap();

                if (bitmap != null) {
                    File directory = new File(Environment.getExternalStorageDirectory().getPath() + "/Download");
                    directory.mkdirs();

                    String fileName = details[1]+details[2].replace(":","_")+"image.jpg"; // Set a desired file name
                    File file = new File(directory, fileName);

                    try {
                        FileOutputStream outputStream = new FileOutputStream(file);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                        Log.d("download_photo", "done");
                        outputStream.flush();
                        outputStream.close();
                        Toast.makeText(getContext(), "Image downloaded", Toast.LENGTH_SHORT).show();
                        // Image is successfully saved
                    } catch (IOException e) {
                        Log.d("download_photo", e.toString());
                        e.printStackTrace();
                        // Error occurred while saving the image
                    }
                }

            }
        });


        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                storageReference.child("report").child(data.get(position).toString()).delete();
                Toast.makeText(getContext(), "Fotografija uklonjena, molimo osvježite stranicu", Toast.LENGTH_SHORT).show();
//                Toast.makeText(getContext(), "Image Removed, Please Reload Page", Toast.LENGTH_SHORT).show();
            }
        });

        return rowView;

    };
}