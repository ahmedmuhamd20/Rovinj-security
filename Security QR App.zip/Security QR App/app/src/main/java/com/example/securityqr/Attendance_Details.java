package com.example.securityqr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Attendance_Details extends AppCompatActivity {

    Button Disapprove, Download;
    ImageView Image, Back, Downloads;
    StorageReference storageReference = FirebaseStorage.getInstance().getReference();
    static Uri Guard_Image;
    DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        setContentView(R.layout.activity_attendance_details);

        Disapprove = findViewById(R.id.remove);
        Image = findViewById(R.id.image);
        Back = findViewById(R.id.back);
        Download = findViewById(R.id.download);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        Attendance_Model Model_Image = Attendance.Selected_Guard;
        String Selected_Image = Model_Image.ID+";"+Model_Image.Name+";"+Model_Image.Time+";"+Model_Image.Date.replace("/","_");

        storageReference.child("attendance").child(Selected_Image+".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                // Got the download URL for 'users/me/profile.png'
                Guard_Image = uri;
                Picasso.get().load(uri).into(Image);
                Download.setVisibility(View.VISIBLE);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Handle any errors
//                Toast.makeText(Attendance_Details.this, "Error while loading image, Please check your network", Toast.LENGTH_SHORT).show();
                Toast.makeText(Attendance_Details.this, "Pogreška prilikom očitavanja, molimo provjerite Vašu internet konekciju", Toast.LENGTH_SHORT).show();
            }
        });

        Download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Drawable drawable = Image.getDrawable();
                Bitmap bitmap = null;
                bitmap = ((BitmapDrawable) drawable).getBitmap();

                if (bitmap != null) {
                    File directory = new File(Environment.getExternalStorageDirectory().getPath() + "/Download");
                    directory.mkdirs();

                    String fileName = Model_Image.Name+Model_Image.Time.replace(":","_")+"Aktivnosti.jpg"; // Set a desired file name
                    File file = new File(directory, fileName);

                    try {
                        FileOutputStream outputStream = new FileOutputStream(file);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                        Log.d("download_photo", "done");
                        outputStream.flush();
                        outputStream.close();
                        Toast.makeText(getApplicationContext(), "Slika je preuzeta", Toast.LENGTH_SHORT).show();
                        // Image is successfully saved
                    } catch (IOException e) {
                        Log.d("download_photo", e.toString());
                        e.printStackTrace();
                        // Error occurred while saving the image
                    }
                }

            }
        });

        Disapprove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    mDatabase.child("Attendance").child(Selected_Image).removeValue();
                    storageReference.child("attendance").child(Selected_Image+".jpg").delete();
                    Toast.makeText(Attendance_Details.this, "Prisustvo nije odobreno, uklonjeno s popisa", Toast.LENGTH_SHORT).show();
                }
                catch (Exception e)
                {
                    Toast.makeText(Attendance_Details.this, "Greška, pokušajte ponovno.", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(Attendance_Details.this, "Error faced while performing action, Try again later", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}