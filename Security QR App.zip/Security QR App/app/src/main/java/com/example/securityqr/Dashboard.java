package com.example.securityqr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Dashboard extends AppCompatActivity {

    CardView Add_QR, QR_List, Attendance, Report, Gallery, Admins;
    Button Guard, Admin;
    TextView Username;
    LinearLayout Logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_dashboard);

        Guard = findViewById(R.id.guards);
        Admin = findViewById(R.id.admin);
        Admins = findViewById(R.id.admins);
        Attendance = findViewById(R.id.attendance);
        Report = findViewById(R.id.report);
        Add_QR = findViewById(R.id.add_qr);
        QR_List = findViewById(R.id.qr_list);
        Username = findViewById(R.id.username);
        Logout = findViewById(R.id.logout);
        Gallery = findViewById(R.id.gallery);

        Username.setText("Dobrodošli, "+MainActivity.emr_string);
//        Username.setText("Welcome, "+MainActivity.emr_string);

        if(MainActivity.type.equals("h"))
        {
            Admins.setVisibility(View.VISIBLE);
        }

        Admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Admins_List.class);
                startActivity(intent);
            }
        });

        Gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), com.example.securityqr.Gallery.class);
                startActivity(intent);
            }
        });

        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Dashboard.this, "Uspješno odjavljeni!", Toast.LENGTH_SHORT).show();
//                Toast.makeText(Dashboard.this, "Logged out successfully!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        Add_QR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Add_QR.class);
                startActivity(intent);
            }
        });

        QR_List.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), View_QR.class);
                startActivity(intent);
            }
        });

        Guard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Guards_List.class);
                startActivity(intent);
            }
        });

        Attendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Attendance.class);
                startActivity(intent);
            }
        });

        Report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), View_Report.class);
                startActivity(intent);
            }
        });

    }
}