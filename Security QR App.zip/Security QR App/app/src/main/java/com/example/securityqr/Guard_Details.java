package com.example.securityqr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Map;

public class Guard_Details extends AppCompatActivity {

    TextView ID, No_Image;
    EditText Name, Contact, Password;
    Button Remove, Update, Image;
    DatabaseReference mDatabase;
    static Uri Guard_Image;
    static boolean Image_Status;
    ProgressBar Bar;
    StorageReference storageReference = FirebaseStorage.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_guard_details);

        Remove = findViewById(R.id.remove);
        Update = findViewById(R.id.update);
        Image = findViewById(R.id.image);
        ID = findViewById(R.id.ID);
        Name = findViewById(R.id.name);
        Contact = findViewById(R.id.contact);
        Password = findViewById(R.id.password);
        No_Image = findViewById(R.id.noimage);
        Bar = findViewById(R.id.bar);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        Image_Status = false;


        Image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Guard_Image.class);
                startActivity(intent);
            }
        });

        mDatabase.child("Users").child(Guards_List.Selected_Guard).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
//                                    Snackbar.make(findViewById(android.R.id.content), "Invalid Credentials", Snackbar.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(), "Problem s podatcima", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(getApplicationContext(), "Data Issue", Toast.LENGTH_SHORT).show();
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Map<String, Object> data = (Map<String,Object>) task.getResult().getValue();

                    Name.setText(data.get("name").toString().replace("_"," "));
                    ID.setText(Guards_List.Selected_Guard);
                    Password.setText(data.get("password").toString().replace("_"," "));
                    Contact.setText(data.get("contact").toString());
                    Bar.setVisibility(View.GONE);
//                    storageReference.child("report").child(Guards_List.Selected_Guard+".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
//                        @Override
//                        public void onSuccess(Uri uri) {
//                            // Got the download URL for 'users/me/profile.png'
//                            Guard_Image = uri;
//                            Image_Status = true;
//                            Image.setVisibility(View.VISIBLE);
//                            Bar.setVisibility(View.GONE);
//                        }
//                    }).addOnFailureListener(new OnFailureListener() {
//                        @Override
//                        public void onFailure(@NonNull Exception exception) {
//                            // Handle any errors
//                            Image_Status = false;
//                            No_Image.setVisibility(View.VISIBLE);
//                            Bar.setVisibility(View.GONE);
//                        }
//                    });
                }
            }
        });

        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = Name.getText().toString();
                String contact = Contact.getText().toString();
                String password = Password.getText().toString();
                String id = Guards_List.Selected_Guard;
                if (validate_data(name) && validate_data(contact) && validate_data(password))
                {
                    mDatabase.child("Users").child(id).child("name").setValue(name.replace(" ","_"));
                    mDatabase.child("Users").child(id).child("contact").setValue(contact);
                    mDatabase.child("Users").child(id).child("password").setValue(password.replace(" ","_"));
                    Toast.makeText(Guard_Details.this, "Podatci ažurirani", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(Guard_Details.this, "Data Updated", Toast.LENGTH_SHORT).show();
                    finish();
                }

            }
        });

        Remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mDatabase.child("Users").child(Guards_List.Selected_Guard).removeValue();
                Toast.makeText(Guard_Details.this, "Korisnik obrisan iz baze podataka", Toast.LENGTH_SHORT).show();
//                Toast.makeText(Guard_Details.this, "User Deleted From Record", Toast.LENGTH_SHORT).show();
                finish();

            }
        });

    }

    boolean validate_data(String data)
    {
        if(data.length()>0)
        {
            if(!data.contains(".") && !data.contains("$") && !data.contains("[") && !data.contains("]") && !data.contains("#") && !data.contains("/"))
            {
                return true;
            }
            else
            {
                Toast.makeText(this, "Izbjegavajte korištenje specijalnih znakova .$[]#/", Toast.LENGTH_SHORT).show();
//                Toast.makeText(this, "Avoid Using Special Characters .$[]#/", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        else
        {
            Toast.makeText(this, "Molimo ispunite sva tražena polja", Toast.LENGTH_SHORT).show();
//            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}