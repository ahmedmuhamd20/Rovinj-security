package com.example.securityqr;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class AttendanceListAdapter extends ArrayAdapter<Attendance_Model> {

    private final Activity context;
    ArrayList<Attendance_Model> data = new ArrayList<>();
    private DatabaseReference db;

    public AttendanceListAdapter(Activity context, ArrayList<Attendance_Model> data) {
        super(context, R.layout.attendance_view, data);
        // TODO Auto-generated constructor stub
        Log.d("view2", String.valueOf(data.size()) );
        this.context=context;
        this.data=data;
    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.attendance_view, null,true);
        db = FirebaseDatabase.getInstance().getReference();

        Log.d("view", String.valueOf(this.data.size()));
        TextView Name = (TextView) rowView.findViewById(R.id.name);
        TextView Date = (TextView) rowView.findViewById(R.id.date);
        TextView Time = (TextView) rowView.findViewById(R.id.time);
        TextView Location = (TextView) rowView.findViewById(R.id.location);

        String time[] = data.get(position).Time.split(":");
        String time_string = time[0]+":"+time[1];
        Name.setText(data.get(position).Name);
        Date.setText(data.get(position).Date);
        Time.setText(time_string);
        Location.setText(data.get(position).Location);
        return rowView;

    };
}