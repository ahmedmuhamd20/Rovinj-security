package com.example.securityqr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Gallery extends AppCompatActivity {

    StorageReference storageReference = FirebaseStorage.getInstance().getReference();
    ListView list;
    ImageView Back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        setContentView(R.layout.activity_gallery);

        list = findViewById(R.id.images);
        Back = findViewById(R.id.back);

        StorageReference storageRef = storageReference.child("report");

        storageRef.listAll()
                .addOnSuccessListener(listResult -> {
                    ArrayList<String> imageNames = new ArrayList<>();
                    for (StorageReference item : listResult.getItems()) {
                        imageNames.add(item.getName());
                    }

                    // Use the imageNames list as needed
                    for (String imageName : imageNames) {
                        Log.d("Image_Name", imageName);
                    }

                    if (imageNames.size()>0)
                    {
                        adapter_attendance(imageNames);
                    }
                    else
                    {
                        Toast.makeText(this, "Nema dostupnih slika", Toast.LENGTH_SHORT).show();
//                        Toast.makeText(this, "No images available", Toast.LENGTH_SHORT).show();
                    }

                })
                .addOnFailureListener(e -> {
                    // Handle any errors that occur during the retrieval
                    Log.d("Image_Error", e.toString());
                    Log.e("Firebase Storage", "Error getting image names", e);
                });

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    void adapter_attendance(ArrayList<String> gallery_list)
    {

        GalleryListAdapter adapter=new GalleryListAdapter(Gallery.this,gallery_list);

        list.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }
}