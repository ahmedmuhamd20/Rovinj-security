package com.example.securityqr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Map;

public class View_QR extends AppCompatActivity {

    DatabaseReference mDatabase;
    ListView list;
    ArrayList<String> QR_Data = new ArrayList<>();
    ImageView reload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_view_qr);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        list = findViewById(R.id.qr);
        reload = findViewById(R.id.reload);


        adaptercall();

        reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adaptercall();
            }
        });

    }

    void adaptercall()
    {
        mDatabase.child("QR").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
//                                    Snackbar.make(findViewById(android.R.id.content), "Invalid Credentials", Snackbar.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    try {
                        Map<String, Object> data = (Map<String,Object>) task.getResult().getValue();
                        QR_Data.clear();

                        if(data.size()>0)
                        {
                            for(String x : data.keySet())
                            {
                                QR_Data.add(String.valueOf(data.get(x)));
                                Log.d("firebase", String.valueOf(data.get(x)));
                            }



                        }

                    }
                    catch (Exception e)
                    {
                        Toast.makeText(View_QR.this, "Nema registriranih QR kodova", Toast.LENGTH_SHORT).show();
//                        Toast.makeText(View_QR.this, "No QR Registered Yet", Toast.LENGTH_SHORT).show();
                    }
                    QRListAdapter adapter=new QRListAdapter(View_QR.this,QR_Data);
                    list.setAdapter(adapter);
                    adapter.notifyDataSetChanged();

                    list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                        @Override
                        public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                            // TODO Auto-generated method stub

//                            for(int i=0;i<QR_Data.size();i++)
//                            {
//                                if(position==i)
//                                {
//                                    Intent intent = new Intent(View_QR.this, report_details.class);
//                                    startActivity(intent);
//                                }
//                                else
//                                {
////                                            Toast.makeText(getApplicationContext(),"Try Again",Toast.LENGTH_SHORT).show();
//                                }
//
//
//                            }


                        }
                    });
                }
            }
        });
    }
}