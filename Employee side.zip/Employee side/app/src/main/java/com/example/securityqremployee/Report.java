package com.example.securityqremployee;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Calendar;

@RequiresApi(api = Build.VERSION_CODES.O)
public class Report extends AppCompatActivity {

    EditText Place, Details;
    ImageView back, Selected_Image;
    Button Submit, Upload;
    String first="", second="", third="";
    private ScrollView scrollView;
    TextView Image_Text;
    Boolean Image_Flag;

    static String Options [][] = {
            {"Krađa - pokušaj krađe", "Provala, prepad, Sabotaža", "Oštećenje - uništenje imovine", "Ništa od navedenog"},
            {"Ulaz/izlaz bez dozvole", "Neispravna - naknadno dostavljena isprava", "Incidentne pojave - stvaranje nereda", "Ponašanje suprotno Pravilniku zaštite od požara", "Nepridržavanje epidemioloških mjera", "Nenajavljen dolazak vanjskih izvođača radova"},
            {"Ciljani pregled vozila", "Ciljana kontrola odobrenja", "Ciljani pregled robe", "Ništa od navedenog"}
    };

    private DatabaseReference mDatabase;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    int SELECT_PICTURE = 200;


    String time[] = LocalTime.now().toString().replace(".","_").split("_");
//        Log.d("firebase_time", time[0]);
    DateFormat formatter = new SimpleDateFormat("dd/MM/yy");
    Calendar obj = Calendar.getInstance();
    String date = formatter.format(obj.getTime()).replace("/","_");

    @Override
    protected void onResume() {
        super.onResume();

        if (MainActivity.emr_string.toString().equals("null"))
        {
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_report);

        Details = findViewById(R.id.report_text);
        Upload = findViewById(R.id.upload);
        Submit = findViewById(R.id.submit);
        back = findViewById(R.id.back);
        scrollView = findViewById(R.id.scroll_view);
        Image_Text = findViewById(R.id.image_text);
        Selected_Image = findViewById(R.id.selected_image);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        Image_Flag = false;


        scrollView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Rect r = new Rect();
                scrollView.getWindowVisibleDisplayFrame(r);
                int screenHeight = scrollView.getRootView().getHeight();
                int keypadHeight = screenHeight - r.bottom;

                // If the keyboard is shown, adjust the scroll position
                if (keypadHeight > screenHeight * 0.15) {
                    int scrollAmount = scrollView.getChildAt(0).getHeight() - scrollView.getHeight();
                    scrollView.scrollTo(0, scrollAmount);
                } else {
                    scrollView.scrollTo(0, 0);
                }
            }
        });


        for(int i=0;i<Report_Options.Selections.length;i++)
        {
            for(int j=0;j<Report_Options.Selections[i].length;j++)
            {
                if(Report_Options.Selections[i][j])
                {
                    if(i==0)
                    {
                        first+=Options[i][j]+";";
                    }
                    else if(i==1)
                    {
                        second+=Options[i][j]+";";
                    }
                    else if(i==2)
                    {
                        third+=Options[i][j]+";";
                    }
                    Log.d("Options_", i+" "+j+" "+Options[i][j]);
                }
            }
        }



        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String details = Details.getText().toString();

                if (MainActivity.emr_string.toString().equals("null"))
                {
                    finish();
                }

                if (details.length()>0)
                {


                    if(first.length()==0)
                    {
                        first="null";
                    }
                    if(second.length()==0)
                    {
                        second="null";
                    }
                    if(third.length()==0)
                    {
                        third="null";
                    }


                    mDatabase.child("Reports").child(MainActivity.emr_string+";"+MainActivity.Name+";"+time[0]+";"+date).child("details").setValue(details);
                    mDatabase.child("Reports").child(MainActivity.emr_string+";"+MainActivity.Name+";"+time[0]+";"+date).child("Krađe_oštećenja_provale").setValue(first);
                    mDatabase.child("Reports").child(MainActivity.emr_string+";"+MainActivity.Name+";"+time[0]+";"+date).child("Nepoštivanje_unutarnjeg_reda").setValue(second);
                    mDatabase.child("Reports").child(MainActivity.emr_string+";"+MainActivity.Name+";"+time[0]+";"+date).child("Ciljani_pregled_(KONTROLA)").setValue(third);
                    if(Image_Flag)
                    {
                        upload(Selected_Image);
                    }
                    Toast.makeText(Report.this, "Izvješće predano", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(Report.this, "Report Submitted", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else {
                    Toast.makeText(Report.this, "Molimo ispišite tekstualno polje", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(Report.this, "Please write something in text box", Toast.LENGTH_SHORT).show();
                }

            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        Upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageChooser();
            }
        });

    }


    void upload(ImageView dp)
    {
        StorageReference storageRef = storage.getReference();

// Create a reference to "mountains.jpg"

        StorageReference mountainsRef = storageRef.child("report_images").child(MainActivity.emr_string+";"+MainActivity.Name+";"+time[0]+";"+date+";"+".jpg");


        // Get the data from an ImageView as bytes
        Bitmap bitmap = ((BitmapDrawable) dp.getDrawable() ).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        Log.d("upload_progress", MainActivity.emr_string+";"+MainActivity.Name.replace("\\n","")+";"+time[0]+";"+date+";"+".jpg");

        UploadTask uploadTask = mountainsRef.putBytes(data);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Log.d("upload_error", exception.toString());
                Toast.makeText(getApplicationContext(), "Greška pri slanju, pokušajte ponovno", Toast.LENGTH_SHORT).show();
//                Toast.makeText(Upload_Image.this, "Error while uploading, try again later", Toast.LENGTH_SHORT).show();
                // Handle unsuccessful uploads
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(getApplicationContext(), "Slika uspješno poslana", Toast.LENGTH_SHORT).show();
//                Toast.makeText(Upload_Image.this, "Image Uploaded Successfully", Toast.LENGTH_SHORT).show();
                finish();
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                // ...
            }
        });
    }


    void imageChooser() {

        // create an instance of the
        // intent of the type image
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);

        // pass the constant to compare it
        // with the returned requestCode
        startActivityForResult(Intent.createChooser(i, "Odaberite fotografiju"), SELECT_PICTURE);
//        startActivityForResult(Intent.createChooser(i, "Select Picture"), SELECT_PICTURE);
    }

    // this function is triggered when user
    // selects the image from the imageChooser
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            // compare the resultCode with the
            // SELECT_PICTURE constant
            if (requestCode == SELECT_PICTURE) {
                // Get the url of the image from data
                Uri selectedImageUri = data.getData();
                if (null != selectedImageUri) {
                    // update the preview image in the layout
                    Selected_Image.setImageURI(selectedImageUri);
                    Image_Text.setText(MainActivity.emr_string+".jpg");
                    Image_Flag = true;
//                    Submit.setVisibility(View.VISIBLE);

                }
            }
        }
    }
}