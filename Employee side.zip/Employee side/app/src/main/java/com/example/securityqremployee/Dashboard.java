package com.example.securityqremployee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.text.Line;
import com.google.firebase.database.core.Repo;

import java.io.IOException;

public class Dashboard extends AppCompatActivity {

    CardView Qr_scan, Report, Upload;
    TextView Username;
    LinearLayout Logout;

    private static final int REQUEST_CAMERA_PERMISSION = 201;

    @Override
    protected void onResume() {
        super.onResume();
        if (MainActivity.emr_string.toString().equals("null"))
        {
            Toast.makeText(this, "Session Timed Out", Toast.LENGTH_SHORT).show();
            finish();
        }
//        Toast.makeText(this, MainActivity.emr_string, Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_dashboard);

        Qr_scan = findViewById(R.id.QR_Scan);
        Report = findViewById(R.id.Report);
        Upload = findViewById(R.id.guards);
        Username = findViewById(R.id.username);
        Logout = findViewById(R.id.logout);

//        Toast.makeText(this, MainActivity.emr_string, Toast.LENGTH_SHORT).show();

        Username.setText("Dobrodošli, "+MainActivity.Name);

        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(Dashboard.this, "Logged out successfully!", Toast.LENGTH_SHORT).show();
                Toast.makeText(Dashboard.this, "Uspješno ste se odjavili!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        Qr_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (MainActivity.emr_string.toString().equals("null"))
                {
                    Toast.makeText(getApplicationContext(), "Session Timed Out", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else
                {
                    if (ActivityCompat.checkSelfPermission(Dashboard.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        Intent intent = new Intent(getApplicationContext(), Camera_Screen.class);
                        startActivity(intent);
                    } else {
                        ActivityCompat.requestPermissions(Dashboard.this, new
                                String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }
                }


            }
        });

        Report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MainActivity.emr_string.toString().equals("null"))
                {
                    Toast.makeText(getApplicationContext(), "Session Timed Out", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else
                {
                    Intent intent = new Intent(getApplicationContext(), Report_Options.class);
                    startActivity(intent);
                }

            }
        });

        Upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (MainActivity.emr_string.toString().equals("null"))
                {
                    Toast.makeText(getApplicationContext(), "Session Timed Out", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else
                {
                    Intent intent = new Intent(getApplicationContext(), Upload_Image.class);
                    startActivity(intent);
                }

            }
        });


    }

}