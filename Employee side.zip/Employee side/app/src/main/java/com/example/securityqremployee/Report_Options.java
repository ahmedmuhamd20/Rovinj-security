package com.example.securityqremployee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Selection;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.core.Repo;

public class Report_Options extends AppCompatActivity {

    ImageView Back;
    Button Next;
    LinearLayout L1, L2, L3;
    TextView O1, O2, O3;
    TextView O11, O12, O13, O14, O21, O22, O23, O24, O25, O26, O31, O32, O33, O34;

    static boolean flag1 = false;

    Boolean FL1, FL2, FL3;

    static Boolean Selections [][] = {{false, false, false, false},{false, false, false, false, false, false},{false, false, false, false}};

    @Override
    protected void onResume() {
        super.onResume();

        if (flag1)
        {
            flag1 = false;
            make_false();
            finish();

        }

        if (MainActivity.emr_string.toString().equals("null"))
        {
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_report_options);

        Next = findViewById(R.id.next);
        Back = findViewById(R.id.back);

        L1 = findViewById(R.id.l1);
        L2 = findViewById(R.id.l2);
        L3 = findViewById(R.id.l3);

        O1 = findViewById(R.id.o1);
        O2 = findViewById(R.id.o2);
        O3 = findViewById(R.id.o3);

        O11 = findViewById(R.id.o11);
        O12 = findViewById(R.id.o12);
        O13 = findViewById(R.id.o13);
        O14 = findViewById(R.id.o14);

        O21 = findViewById(R.id.o21);
        O22 = findViewById(R.id.o22);
        O23 = findViewById(R.id.o23);
        O24 = findViewById(R.id.o24);
        O25 = findViewById(R.id.o25);
        O26 = findViewById(R.id.o26);

        O31 = findViewById(R.id.o31);
        O32 = findViewById(R.id.o32);
        O33 = findViewById(R.id.o33);
        O34 = findViewById(R.id.o34);

        FL1 = false;
        FL2 = false;
        FL3 = false;

        if (flag1)
        {
            flag1 = false;
            make_false();
            finish();
        }


        O1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(FL1)
                {
                    L1.setVisibility(View.GONE);
                    FL1 = false;

                    O1.setBackgroundDrawable(getResources().getDrawable(R.drawable.good));
                    O1.setTextColor(getResources().getColor(R.color.jerBlue2));
                }
                else
                {
                    FL1 = true;
                    L1.setVisibility(View.VISIBLE);
                    O1.setBackgroundDrawable(getResources().getDrawable(R.drawable.good_selected));
                    O1.setTextColor(getResources().getColor(R.color.white));

                    Selections[0][0] = false;
                    Selections[0][1] = false;
                    Selections[0][2] = false;
                    Selections[0][3] = false;

                    O11.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O11.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O12.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O12.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O13.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O13.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O14.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O14.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O11.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[0][0])
                            {
                                Selections[0][0] = false;
                                O11.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O11.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[0][0] = true;
                                O11.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O11.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O12.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[0][1])
                            {
                                Selections[0][1] = false;
                                O12.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O12.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[0][1] = true;
                                O12.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O12.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O13.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[0][2])
                            {
                                Selections[0][2] = false;
                                O13.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O13.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[0][2] = true;
                                O13.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O13.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O14.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[0][3])
                            {
                                Selections[0][3] = false;
                                O14.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O14.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[0][3] = true;
                                O14.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O14.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                }
            }
        });


        O2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(FL2)
                {
                    L2.setVisibility(View.GONE);
                    FL2 = false;
                    O2.setBackgroundDrawable(getResources().getDrawable(R.drawable.good));
                    O2.setTextColor(getResources().getColor(R.color.jerBlue2));
                }
                else
                {
                    FL2 = true;
                    L2.setVisibility(View.VISIBLE);
                    O2.setBackgroundDrawable(getResources().getDrawable(R.drawable.good_selected));
                    O2.setTextColor(getResources().getColor(R.color.white));

                    Selections[1][0] = false;
                    Selections[1][1] = false;
                    Selections[1][2] = false;
                    Selections[1][3] = false;
                    Selections[1][4] = false;
                    Selections[1][5] = false;

                    O21.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O21.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O22.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O22.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O23.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O23.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O24.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O24.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O25.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O25.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O26.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O26.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O21.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[1][0])
                            {
                                Selections[1][0] = false;
                                O21.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O21.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[1][0] = true;
                                O21.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O21.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O22.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[1][1])
                            {
                                Selections[1][1] = false;
                                O22.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O22.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[1][1] = true;
                                O22.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O22.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O23.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[1][2])
                            {
                                Selections[1][2] = false;
                                O23.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O23.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[1][2] = true;
                                O23.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O23.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O24.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[1][3])
                            {
                                Selections[1][3] = false;
                                O24.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O24.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[1][3] = true;
                                O24.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O24.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O25.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[1][4])
                            {
                                Selections[1][4] = false;
                                O25.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O25.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[1][4] = true;
                                O25.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O25.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O26.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[1][5])
                            {
                                Selections[1][5] = false;
                                O26.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O26.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[1][5] = true;
                                O26.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O26.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                }
            }
        });


        O3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(FL3)
                {
                    L3.setVisibility(View.GONE);
                    FL3 = false;
                    O3.setBackgroundDrawable(getResources().getDrawable(R.drawable.good));
                    O3.setTextColor(getResources().getColor(R.color.jerBlue2));
                }
                else
                {
                    FL3 = true;
                    L3.setVisibility(View.VISIBLE);
                    O3.setBackgroundDrawable(getResources().getDrawable(R.drawable.good_selected));
                    O3.setTextColor(getResources().getColor(R.color.white));


                    Selections[2][0] = false;
                    Selections[2][1] = false;
                    Selections[2][2] = false;
                    Selections[2][3] = false;

                    O31.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O31.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O32.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O32.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O33.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O33.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O34.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                    O34.setTextColor(getResources().getColor(R.color.jerBlue2));

                    O31.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[2][0])
                            {
                                Selections[2][0] = false;
                                O31.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O31.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[2][0] = true;
                                O31.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O31.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O32.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[2][1])
                            {
                                Selections[2][1] = false;
                                O32.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O32.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[2][1] = true;
                                O32.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O32.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O33.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[2][2])
                            {
                                Selections[2][2] = false;
                                O33.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O33.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[2][2] = true;
                                O33.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O33.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                    O34.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (Selections[2][3])
                            {
                                Selections[2][3] = false;
                                O34.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent));
                                O34.setTextColor(getResources().getColor(R.color.jerBlue2));
                            }
                            else
                            {
                                Selections[2][3] = true;
                                O34.setBackgroundDrawable(getResources().getDrawable(R.drawable.excellent_selected));
                                O34.setTextColor(getResources().getColor(R.color.white));
                            }

                        }
                    });

                }
            }
        });

        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Boolean flag = false;

                for(int i=0;i<Selections.length;i++)
                {
                    for (int j=0;j<Selections[i].length;j++)
                    {
                        if(Selections[i][j])
                        {
                            flag = true;
                        }
                    }
                }

                if(flag)
                {
                    flag1 = true;
                    Intent intent = new Intent(getApplicationContext(), Report.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(Report_Options.this, "Odaberite najmanje jednu vrstu događaja", Toast.LENGTH_SHORT).show();
//                    Toast.makeText(Report_Options.this, "Please select at least one category", Toast.LENGTH_SHORT).show();
                }

            }
        });

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    void make_false()
    {
        for(int i=0;i<Selections.length;i++)
        {
            for(int j=0;j<Selections[i].length;j++)
            {
                if(Selections[i][j])
                {
                    Selections[i][j]=false;
                }
            }
        }
    }
}