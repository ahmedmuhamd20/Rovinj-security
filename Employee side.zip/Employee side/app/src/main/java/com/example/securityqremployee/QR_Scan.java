package com.example.securityqremployee;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ImageFormat;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.ToneGenerator;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class QR_Scan extends AppCompatActivity{

    private SurfaceView surfaceView;
    private BarcodeDetector barcodeDetector;
    private CameraSource cameraSource;
    private static final int REQUEST_CAMERA_PERMISSION = 201;
    private ToneGenerator toneGen1;
    private TextView barcodeText;
    private String barcodeData;
    boolean flag;
    ImageView back;
    Location location;
    FirebaseStorage storage = FirebaseStorage.getInstance();

    private DatabaseReference mDatabase;

    @Override
    protected void onResume() {
        super.onResume();

        if (MainActivity.emr_string.toString().equals("null"))
        {
            finish();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_qr_scan);


        if (MainActivity.emr_string.toString().equals("null"))
        {
            Toast.makeText(this, "Session Timed Out", Toast.LENGTH_SHORT).show();
            finish();
        }

        toneGen1 = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
        surfaceView = findViewById(R.id.surface_view);
        barcodeText = findViewById(R.id.barcode_text);
        back = findViewById(R.id.back);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        initialiseDetectorsAndSources();
        flag = false;

        mDatabase.child("Attendance").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
//                    Log.e("firebase", "Error getting data", task.getException());
                    Log.e("firebase", "Pogreška pri dohvaćanju podataka", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue()));
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void initialiseDetectorsAndSources() {

        //Toast.makeText(getApplicationContext(), "Barcode scanner started", Toast.LENGTH_SHORT).show();

        barcodeDetector = new BarcodeDetector.Builder(this)
                .setBarcodeFormats(Barcode.ALL_FORMATS)
                .build();

        cameraSource = new CameraSource.Builder(this, barcodeDetector)
                .setRequestedPreviewSize(1920, 1080)
                .setAutoFocusEnabled(true) //you should add this feature
                .build();

        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                try {
                    if (ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        cameraSource.start(surfaceView.getHolder());
                    } else {
                        ActivityCompat.requestPermissions(QR_Scan.this, new
                                String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                cameraSource.stop();
            }
        });


        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {
                // Toast.makeText(getApplicationContext(), "To prevent memory leaks barcode scanner has been stopped", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> barcodes = detections.getDetectedItems();
                if (barcodes.size() != 0) {

                    barcodeText.post(new Runnable() {

                        @Override
                        public void run() {

                            if (barcodes.valueAt(0).displayValue != null && !flag) {

                                flag = true;
                                Log.d("QR_if", "if");

                                barcodeText.removeCallbacks(null);
                                barcodeData = barcodes.valueAt(0).displayValue;
//                                barcodeText.setText(barcodeData);
                                toneGen1.startTone(ToneGenerator.TONE_CDMA_PIP, 150);

                                if (MainActivity.emr_string.toString().equals("null"))
                                {
                                    finish();
                                }

                                mDatabase.child("QR").child(barcodeData.replace(" ","_").replace(".","_").replace("$","_").replace("#","_").replace("[","_").replace("]","_").replace("/","_").replace(",","_")).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                    @RequiresApi(api = Build.VERSION_CODES.O)
                                    @Override
                                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                                        if (!task.isSuccessful()) {
                                            Toast.makeText(getApplicationContext(), "Neispravno korisničko ime", Toast.LENGTH_SHORT).show();
//                                            Toast.makeText(getApplicationContext(), "Invalid Username", Toast.LENGTH_SHORT).show();
                                            Log.e("firebase", "Error getting data", task.getException());
                                        }
                                        else {
                                            if(String.valueOf(task.getResult().getValue()).equals(barcodeData))
                                            {

                                                String time[] = LocalTime.now().toString().replace(".","_").split("_");
                                                Log.d("firebase_time", time[0]);
                                                DateFormat formatter = new SimpleDateFormat("dd/MM/yy");
                                                Calendar obj = Calendar.getInstance();
                                                String date = formatter.format(obj.getTime()).replace("/","_");
                                                mDatabase.child("Attendance").child(MainActivity.emr_string+";"+MainActivity.Name+";"+time[0]+";"+date).setValue(barcodeData);

                                                StorageReference storageRef = storage.getReference();

                                                StorageReference mountainsRef = storageRef.child("attendance").child(MainActivity.emr_string+";"+MainActivity.Name+";"+time[0]+";"+date+".jpg");

                                                Bitmap bitmap = Camera_Screen.photo;
                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                                                byte[] data = baos.toByteArray();

                                                UploadTask uploadTask = mountainsRef.putBytes(data);
                                                uploadTask.addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception exception) {
                                                        Toast.makeText(getApplicationContext(), "Greška prilikom slanja, pokušajte ponovno", Toast.LENGTH_SHORT).show();
//                                                        Toast.makeText(getApplicationContext(), "Error while uploading, try again later", Toast.LENGTH_SHORT).show();
                                                        // Handle unsuccessful uploads
                                                    }
                                                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                    @Override
                                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                        Toast.makeText(getApplicationContext(), "QR kod otkucan", Toast.LENGTH_SHORT).show();
                                                        finish();
                                                        // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                                                        // ...
                                                    }
                                                });

                                            }
                                            else
                                            {
//                                                Toast.makeText(getApplicationContext(), "Invalid QR", Toast.LENGTH_SHORT).show();
                                                Toast.makeText(getApplicationContext(), "Neispravan QR kod", Toast.LENGTH_SHORT).show();
                                            }
                                            Log.d("firebase", String.valueOf(task.getResult().getValue()));
                                        }
                                    }
                                });

//                                Toast.makeText(QR_Scan.this, barcodeData.toString(), Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        }
                    });

                }
            }
        });
    }

}