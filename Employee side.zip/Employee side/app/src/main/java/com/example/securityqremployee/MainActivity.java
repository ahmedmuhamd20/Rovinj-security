package com.example.securityqremployee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    ImageView fb, google;
    static Button login;
    static EditText emr, pname;
    static String emr_string, pname_string;
    static RelativeLayout progress;
    static String Name;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Enable immersive mode
        if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_main);

        fb = findViewById(R.id.fb);
        google = findViewById(R.id.google);
        login = findViewById(R.id.loginButton);
        emr = findViewById(R.id.EMR);
        pname = findViewById(R.id.PNAME);
        progress = findViewById(R.id.progress);
        mDatabase = FirebaseDatabase.getInstance().getReference();

//        emr.setText("");
//        pname.setText("");

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                login.setVisibility(View.GONE);

                progress.setVisibility(View.VISIBLE);
                if (login.getVisibility()==View.GONE && progress.getVisibility()==View.VISIBLE) {

//                            Snackbar.make(findViewById(android.R.id.content), "Invalid Credentials", Snackbar.LENGTH_SHORT).show();
                    emr_string = "";
                    pname_string = "";
                    emr_string = emr.getText().toString();
                    pname_string = pname.getText().toString();

                    if (emr.getText().toString().length() == 0 || pname.getText().toString().length() == 0) {
                        login.setVisibility(View.VISIBLE);
                        progress.setVisibility(View.GONE);
                        Snackbar.make(findViewById(android.R.id.content), "Unesite vaše podatke", Snackbar.LENGTH_SHORT).show();
//                        Snackbar.make(findViewById(android.R.id.content), "Please Enter Credentials", Snackbar.LENGTH_SHORT).show();

                    } else {
                        emr_string = "";
                        pname_string = "";
                        emr_string = emr.getText().toString();
                        pname_string = pname.getText().toString();

                        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot snapshot) {

                                if (snapshot.child("Users").hasChild(emr_string)) {

                                    mDatabase.child("Users").child(emr_string).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                                            if (!task.isSuccessful()) {
                                                login.setVisibility(View.VISIBLE);
                                                progress.setVisibility(View.GONE);
//                                    Snackbar.make(findViewById(android.R.id.content), "Invalid Credentials", Snackbar.LENGTH_SHORT).show();
                                                Toast.makeText(MainActivity.this, "Pogrešno korisničko ime ili lozinka.", Toast.LENGTH_SHORT).show();
                                                Log.e("firebase", "Pogreška pri dohvaćanju podataka", task.getException());
//                                                Log.e("firebase", "Error getting data", task.getException());
                                            }
                                            else {
                                                Map<String, Object> data = (Map<String,Object>) task.getResult().getValue();
                                                if(String.valueOf(data.get("password")).equals(pname_string))
                                                {
                                                    login.setVisibility(View.VISIBLE);
                                                    progress.setVisibility(View.GONE);
                                                    Name = String.valueOf(data.get("name"));
                                                    Intent intent = new Intent(getApplicationContext(), Dashboard.class);
                                                    startActivity(intent);
                                                }
                                                else
                                                {
                                                    login.setVisibility(View.VISIBLE);
                                                    progress.setVisibility(View.GONE);
//                                                    Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                                                    Toast.makeText(MainActivity.this, "Neispravni podatci", Toast.LENGTH_SHORT).show();
                                                }
                                                Log.d("firebase", String.valueOf(data.get("name")));
                                            }
                                        }
                                    });

                                }
                                else
                                {
                                    login.setVisibility(View.VISIBLE);
                                    progress.setVisibility(View.GONE);
                                    Log.d("firebase_users", "Korisnik ne postoji!");
//                                    Log.d("firebase_users", "User Does Not Exists!");
                                    Toast.makeText(MainActivity.this, "Korisnik ne postoji!", Toast.LENGTH_SHORT).show();
//                                    Toast.makeText(MainActivity.this, "User Does Not Exists!", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });



                    }
                } else {
                    Snackbar.make(findViewById(android.R.id.content), "Pogreška prilikom povezivanja", Snackbar.LENGTH_SHORT).show();
//                    Snackbar.make(findViewById(android.R.id.content), "Connection Error", Snackbar.LENGTH_SHORT).show();
                    login.setVisibility(View.VISIBLE);

                    progress.setVisibility(View.GONE);
                }

            }
        });

    }


    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null;
    }

    public boolean hasActiveInternetConnection() {
        if (isNetworkAvailable()) {
            try {
                HttpURLConnection urlc = (HttpURLConnection) (new URL("http://www.google.com").openConnection());
                urlc.setRequestProperty("User-Agent", "Test");
                urlc.setRequestProperty("Connection", "close");
                urlc.setConnectTimeout(1500);
                urlc.connect();
                return (urlc.getResponseCode() == 200);
            } catch (IOException e) {
                Snackbar.make(findViewById(android.R.id.content), "Molimo provjerite Vašu internet konekciju", Snackbar.LENGTH_SHORT).show();
//                Snackbar.make(findViewById(android.R.id.content), "Please Check Your Network Connection", Snackbar.LENGTH_SHORT).show();

                Log.e("LOG_TAG", "Error checking internet connection", e);
            }
        } else {

            Snackbar.make(findViewById(android.R.id.content), "Mreža nije dostupna!", Snackbar.LENGTH_SHORT).show();
//            Snackbar.make(findViewById(android.R.id.content), "No Network Available!", Snackbar.LENGTH_SHORT).show();
            Log.d("LOG_TAG", "No network available!");
        }
        return false;
    }

}