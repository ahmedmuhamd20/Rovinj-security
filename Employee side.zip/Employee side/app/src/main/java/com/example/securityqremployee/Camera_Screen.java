package com.example.securityqremployee;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class Camera_Screen extends Activity {
    private static final int CAMERA_REQUEST = 1888;
    private ImageView imageView, back;
    Button Next;
    static Bitmap photo;
    static boolean flag = false;

    @Override
    protected void onResume() {
        super.onResume();

        if (flag)
        {
            flag = false;
            finish();
        }

        if (MainActivity.emr_string.toString().equals("null"))
        {
            finish();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_screen);
        this.imageView = (ImageView)this.findViewById(R.id.imageView1);
        ImageView photoButton = (ImageView) this.findViewById(R.id.button1);
        Next = findViewById(R.id.submit);
        back = findViewById(R.id.back);

        if (flag)
        {
            flag = false;
            finish();
        }

        if (MainActivity.emr_string.toString().equals("null"))
        {
            finish();
        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag = true;
                Intent intent = new Intent(getApplicationContext(), QR_Scan.class);
                startActivity(intent);
            }
        });

        photoButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            photo = (Bitmap) data.getExtras().get("data");
            imageView.setImageBitmap(photo);
            Next.setVisibility(View.VISIBLE);
        }
    }
}