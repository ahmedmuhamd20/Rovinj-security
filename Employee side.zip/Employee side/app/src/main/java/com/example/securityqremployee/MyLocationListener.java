package com.example.securityqremployee;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

public class MyLocationListener implements LocationListener {

    @Override
    public void onLocationChanged(Location location) {
        // handle location update here
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // handle status change here
    }

    @Override
    public void onProviderEnabled(String provider) {
        // handle provider enabled here
    }

    @Override
    public void onProviderDisabled(String provider) {
        // handle provider disabled here
    }
}

